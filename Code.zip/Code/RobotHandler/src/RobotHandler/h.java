/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotHandler;

/**
 *
 * @author jafo
 */
public class h {
    public static void ps(Object obj){
        System.out.println(obj.toString());
    }
}
