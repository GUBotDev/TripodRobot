/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotHandler;

/**
 *
 * @author Rollie
 */
public class StepperThread implements Runnable{
    private static Steppers steppers;
    private static final int DRIVINGMODE = 1;
    private final int interval = 10000000;//1000000.0f;//Pause time in nanoSeconds between steps, for halfStepping and full step
    private final float stepMultiplier = 1.0f;//
    private static Thread t;
    private float leftRatio = 1.0f;
    private float rightRatio = 1.0f;
    private float left = 0.0f;
    private float right = 0.0f;
    private int steps;
    
    @Override
    public void run() {
        while(true){
            try {
                readLR();
                
                if (right - left > 0){
                    turnRight(right - left);
                }
                else if (right - left < 0){
                    turnLeft(Math.abs(right - left));
                }
                else if (right - left == 0){
                    normalize();
                }
                
                setSpeed(RobotHandler.returnRobot().returnSpeed());
            } catch (InterruptedException ex) {}
        }
    }
    
    public void start(){
        if(t == null){
            steppers = new Steppers(DRIVINGMODE,
                0,1,2,3,
                4,5,6,7,
                18,19,20,21,
                22,23,24,25);
            
            h.ps("Enabling");
            steppers.enable();
            h.ps("Enabled");
    
            t = new Thread(this, "Steppers");
            t.start();
            
            steppers.setDrivingModeRight(4);
            steppers.setDrivingModeLeft(4);
        }
    }
    
    /***
     * 
     * @param input Speed from -1 to 1
     * @throws InterruptedException 
     * 
     * This function utilizes microstepping for accuracy and speed, similar to an 
     * automatic shifter in a car.
     */
    public void setSpeed(float input) throws InterruptedException{
        int intervalDec = (int)((float)interval / (float)Math.abs(input));
        
        if(intervalDec > interval){
            intervalDec = (int)interval;
        }
        
        if(input > 1.0f){
            input = 1.0f;
        }
        else if (input < -1.0f){
            input = -1.0f;
        }
        
        steps = (int) (stepMultiplier * input);

        if(input < 0){
            stepForward(steps, intervalDec);
        }
        else if (input > 0){
            stepBackward(steps, intervalDec);
        }
    }
    
    public void normalize(){
        rightRatio = 1.0f;
        leftRatio = 1.0f;
    }
    
    public void turnLeft(float amount){
        amount = amount / 100;
        
        rightRatio = 1.0f;
        leftRatio = 1.0f - amount;
    }
    
    public void turnRight(float amount){
        amount = amount / 100;
        
        rightRatio = 1.0f - amount;
        leftRatio = 1.0f;
    }
    
    public void stepForward(int steps, int interval) throws InterruptedException{
        steppers.move(Math.abs(steps), interval, DRIVINGMODE, leftRatio, rightRatio);
    }
    
    public void stepBackward(int steps, int interval) throws InterruptedException{
        steppers.move(-Math.abs(steps), interval, DRIVINGMODE, leftRatio, rightRatio);
    }

    public static void shutdown(){
        h.ps("Disabling");
        steppers.disable();
        h.ps("Shutting down");
        steppers.shutdown();
        
        System.exit(0);
    }
    
    public static void enable(){
        steppers.enable();
    }
    
    public static void disable(){
        steppers.disable();
    }
    
    public void readLR(){
        left = RobotHandler.returnRobot().returnLeft();
        right = RobotHandler.returnRobot().returnRight();
    }
}
