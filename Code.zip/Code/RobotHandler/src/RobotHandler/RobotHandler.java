/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotHandler;

import java.io.IOException;


public class RobotHandler {
    private static final boolean BALANCE = false;
    private static final boolean WAITFORCONNECTION = false;
    private static final int RUNTIME = 120;//secondsS
    
    private static ControlConnector connection;
    private static ReadMPUThread mpuT;
    private static Robot robot;
    public static PIDTuner pidT;
    public static StepperThread steppersT;
    
    /**
     * @param args
     * @throws InterruptedException
     * @throws IOException 
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        h.ps("Start");
        
        initializeRobot();
        
        h.ps("Pick up");

        Thread.sleep(2000);
        start();
        Thread.sleep(250);
        StepperThread.shutdown();
        h.ps("done");
    }
    
    public static void initializeRobot() throws IOException, InterruptedException{
        robot = new Robot();
        //mpuT = new ReadMPUThread();
        steppersT = new StepperThread();
        //pidT = new PIDTuner();
        
        h.ps("Waiting for connection...");
        
        connection = new ControlConnector(WAITFORCONNECTION);
        
        //if(BALANCE){
            //Mpu6050Controller.initialize();
        //}
    }
    
    public static void start() throws IOException, InterruptedException{
        //mpuT.start();
        steppersT.start();
        //pidT.start();
        connection.start();
        
        robot.turnOnMotors();
        robot.setBalancer(BALANCE);
        
        boolean warning = false;
        long startTime = System.currentTimeMillis();
    
        while((System.currentTimeMillis() - startTime) < 1000 * RUNTIME)
        {
            try{
                boolean[] vals = connection.readControls();

                robot.setUp(vals[0]);
                robot.setDown(vals[1]);
                robot.setLeft(vals[3]);
                robot.setRight(vals[2]);

                robot.checkControl();
            }
            catch(IOException ex){}

            if(BALANCE){
                robot.balance();
            }
            
            if (!warning && (System.currentTimeMillis() - startTime) > (1000 * RUNTIME) - 5000){
                h.ps("STOPPING IN 5 SECONDS.");
                
                warning = true;
            }
        }
    }
    
    public static Robot returnRobot(){
        return robot;
    }
}

